//
//  LocationViewController.swift
//  IPGeoLocation
//
//  Created by Muhammad Kamran on 3/16/17.
//  Copyright © 2017 Solutions 4 Mobility. All rights reserved.
//

import UIKit
import MapKit

class LocationViewController: UIViewController {

    @IBOutlet weak var mapView: MKMapView!
    var location: Location!
    
    //MARK: View's Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let latitude = location.latitude, let longitude = location.longitude {
            let center = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
            let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
            mapView.setRegion(region, animated: true)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.navigationBar.isHidden = false
    }
}
