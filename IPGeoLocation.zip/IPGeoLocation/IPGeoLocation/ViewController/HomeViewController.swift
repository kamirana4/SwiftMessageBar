//
//  HomeViewController.swift
//  IPGeoLocation
//
//  Created by Muhammad Kamran on 3/16/17.
//  Copyright © 2017 Solutions 4 Mobility. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var ipTextField: UITextField!
    @IBOutlet weak var statusLabel: UILabel!
    
    //Data Manager
    let dataManager = DataManager()
    
    //Location
    var location: Location?
    
    //MARK: View's Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ipTextField.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.navigationBar.isHidden = false
    }
    
    //MARK: Load location for the given ip
    /*
     @params: ip - IP Address for the country
     */
    public func loadLocationFor(ip: String) {
        
        dataManager.sendRequest(ipAddress: ip) {[weak self] (location, error) in
            if let _ = error {
                self?.statusLabel.text = "Plase enter valid IP(e.g, 47.52.33.214)"
                return
            }
            self?.location = location
            self?.statusLabel.text = location?.countryName ?? ""
        }
    }
    
    //MARK: User Interactions
    @IBAction func locationButtonAction(_ sender: Any) {
        if let location = location {
            let mainStoryBoard = UIStoryboard.init(name: "Main", bundle: nil)
            let locationViewController = mainStoryBoard.instantiateViewController(withIdentifier: "LocationViewControllerID") as! LocationViewController
            locationViewController.location = location
            self.navigationController?.pushViewController(locationViewController, animated: true)
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
}

extension HomeViewController: UITextFieldDelegate {
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if let text = textField.text, !text.isEmpty{
            loadLocationFor(ip: text)
        }
    }
}
