//
//  DataManager.swift
//  IPGeoLocation
//
//  Created by Muhammad Kamran on 3/16/17.
//  Copyright © 2017 Solutions 4 Mobility. All rights reserved.
//

import Foundation

class DataManager {
    
    
    func sendRequest(ipAddress: String, completion: @escaping ((Location?, Error?) -> Swift.Void)) {
        let urlString = "http://freegeoip.net/json/\(ipAddress)"
        var request = URLRequest(url: URL(string: urlString)!)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) {data, response, error in

            do {
                if let locationJson = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any] {
                    let location  = Location()
                    location.countryName = locationJson["country_name"] as? String
                    location.latitude = locationJson["latitude"] as? Double
                    location.longitude = locationJson["longitude"] as? Double
                    DispatchQueue.main.async {
                        completion(location, nil)
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
            }
            }.resume()
    }
}
