//
//  Location.swift
//  IPGeoLocation
//
//  Created by Muhammad Kamran on 3/16/17.
//  Copyright © 2017 Solutions 4 Mobility. All rights reserved.
//

import Foundation

class Location {
    
    var countryName: String?
    
    var latitude: Double?
    
    var longitude: Double?
}
