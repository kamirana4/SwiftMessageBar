//
//  SplashViewController.swift
//  IPGeoLocation
//
//  Created by Muhammad Kamran on 3/16/17.
//  Copyright © 2017 Solutions 4 Mobility. All rights reserved.
//

import UIKit

class SplashViewController: UIViewController {

    //MARK: View's Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.navigationBar.isHidden = true
        
        let time: TimeInterval = 3
        Timer.scheduledTimer(withTimeInterval: time, repeats: false) {[weak self] (timer) in
            timer.invalidate()
            let mainStoryBoard = UIStoryboard.init(name: "Main", bundle: nil)
            let homeViewController = mainStoryBoard.instantiateViewController(withIdentifier: "HomeViewControllerID") as! HomeViewController
            self?.navigationController?.pushViewController(homeViewController, animated: true)
        }
    }
}

